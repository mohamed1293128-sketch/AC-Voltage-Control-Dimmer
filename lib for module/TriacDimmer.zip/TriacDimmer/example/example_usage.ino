#include <TriacDimmer.h>

// -----------------------------------------------------------------------------
// TRIAC Dimmer Configuration
// -----------------------------------------------------------------------------

// GPIO connected to the zero-cross detection circuit
constexpr uint8_t ZERO_CROSS_PIN = 27;

// GPIO connected to the TRIAC optocoupler gate
constexpr uint8_t TRIAC_GATE_PIN = 26;

// Create the TRIAC dimmer instance
TriacDimmer dimmer(ZERO_CROSS_PIN, TRIAC_GATE_PIN);


void setup() {

  // Initialize the zero-cross detector and TRIAC control
  dimmer.begin();

}


void loop() {

  // Set AC output to 50% power
  dimmer.setPercent(50);
  delay(1000);

  // Disable the TRIAC completely
  dimmer.setPercent(0);
  delay(1000);

  // Set AC output to 70% power
  dimmer.setPercent(70);
  delay(1000);

  // Set AC output to maximum power
  dimmer.setPercent(100);
  delay(1000);

}
