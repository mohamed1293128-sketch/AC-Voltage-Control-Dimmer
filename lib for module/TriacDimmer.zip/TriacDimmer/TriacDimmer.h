#ifndef TRIAC_DIMMER_H
#define TRIAC_DIMMER_H

#include <Arduino.h>

class TriacDimmer {

public:

    TriacDimmer(
        uint8_t zeroCrossPin,
        uint8_t triacGatePin
    );

    void begin();

    void setPercent(int percent);

    int getPercent() const;

    bool isEnabled() const;

private:

    uint8_t _zeroCrossPin;
    uint8_t _triacGatePin;

    volatile uint16_t _firingDelay_us;
    volatile bool _enabled;
    volatile int _currentPercent;

    hw_timer_t* _timer;

    static TriacDimmer* _instance;

    static void IRAM_ATTR zeroCrossISR();
    static void IRAM_ATTR fireTriacISR();

    void IRAM_ATTR handleZeroCross();
    void IRAM_ATTR handleFireTriac();

    static constexpr uint16_t MAX_DELAY_US = 8500;
    static constexpr uint16_t MIN_DELAY_US = 500;
    static constexpr uint16_t GATE_PULSE_US = 300;
};

#endif
