#include "TriacDimmer.h"

TriacDimmer* TriacDimmer::_instance = nullptr;


// ================================
// CONSTRUCTOR
// ================================

TriacDimmer::TriacDimmer(
    uint8_t zeroCrossPin,
    uint8_t triacGatePin
)
    : _zeroCrossPin(zeroCrossPin),
      _triacGatePin(triacGatePin),
      _firingDelay_us(MAX_DELAY_US),
      _enabled(true),
      _currentPercent(50),
      _timer(nullptr)
{
    _instance = this;
}


// ================================
// BEGIN
// ================================

void TriacDimmer::begin()
{
    pinMode(_zeroCrossPin, INPUT);

    pinMode(_triacGatePin, OUTPUT);
    digitalWrite(_triacGatePin, LOW);


    // 1 MHz timer
    // 1 tick = 1 microsecond

    _timer = timerBegin(1000000);

    timerAttachInterrupt(
        _timer,
        &TriacDimmer::fireTriacISR
    );

    timerStop(_timer);


    // Zero-cross interrupt

    attachInterrupt(
        digitalPinToInterrupt(_zeroCrossPin),
        &TriacDimmer::zeroCrossISR,
        FALLING
    );
}


// ================================
// SET DIMMING PERCENTAGE
// ================================

void TriacDimmer::setPercent(int percent)
{
    percent = constrain(percent, 0, 100);

    _currentPercent = percent;


    // OFF

    if (percent <= 0)
    {
        _enabled = false;

        _firingDelay_us = MAX_DELAY_US;

        digitalWrite(
            _triacGatePin,
            LOW
        );

        return;
    }


    // ON

    _enabled = true;


    _firingDelay_us = map(
        percent,
        1,
        100,
        MAX_DELAY_US,
        MIN_DELAY_US
    );


    _firingDelay_us = constrain(
        _firingDelay_us,
        MIN_DELAY_US,
        MAX_DELAY_US
    );
}


// ================================
// GET PERCENT
// ================================

int TriacDimmer::getPercent() const
{
    return _currentPercent;
}


// ================================
// ENABLE STATUS
// ================================

bool TriacDimmer::isEnabled() const
{
    return _enabled;
}


// ================================
// ZERO CROSS ISR
// ================================

void IRAM_ATTR TriacDimmer::zeroCrossISR()
{
    if (_instance)
    {
        _instance->handleZeroCross();
    }
}


// ================================
// ZERO CROSS HANDLER
// ================================

void IRAM_ATTR TriacDimmer::handleZeroCross()
{
    static uint32_t lastCross = 0;

    uint32_t now = micros();


    // Noise filter

    if (now - lastCross < 7000)
        return;

    lastCross = now;


    if (!_enabled)
        return;


    // Reset timer

    timerWrite(
        _timer,
        0
    );


    // Trigger TRIAC after delay

    timerAlarm(
        _timer,
        _firingDelay_us,
        false,
        0
    );


    timerStart(_timer);
}


// ================================
// TRIAC FIRE ISR
// ================================

void IRAM_ATTR TriacDimmer::fireTriacISR()
{
    if (_instance)
    {
        _instance->handleFireTriac();
    }
}


// ================================
// TRIAC FIRE HANDLER
// ================================

void IRAM_ATTR TriacDimmer::handleFireTriac()
{
    if (!_enabled)
        return;


    // Trigger optocoupler

    digitalWrite(
        _triacGatePin,
        HIGH
    );


    // Keep gate HIGH

    ets_delay_us(
        GATE_PULSE_US
    );


    // Gate LOW

    digitalWrite(
        _triacGatePin,
        LOW
    );


    // Stop timer until next zero crossing

    timerStop(_timer);
}
